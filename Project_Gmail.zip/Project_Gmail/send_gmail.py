import os
import pandas as pd
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
import base64
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

SCOPES = ['https://www.googleapis.com/auth/gmail.send']

def gmail_authenticate():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    service = build('gmail', 'v1', credentials=creds)
    return service

def create_message_with_attachment(to, subject, message_text, attachment_file=None):
    message = MIMEMultipart()
    message['to'] = to
    message['subject'] = subject
    message.attach(MIMEText(message_text, 'html'))

    if attachment_file:
        try:
            with open(attachment_file, 'rb') as attachment:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename= {os.path.basename(attachment_file)}')
            message.attach(part)
        except Exception as e:
            print(f"Error attaching file {attachment_file}: {e}")

    raw = base64.urlsafe_b64encode(message.as_bytes()).decode('utf-8')
    return {'raw': raw}

def send_email(service, to, message):
    try:
        sent_message = (service.users().messages().send(userId="me", body=message).execute())
        print(f"Message sent to {to}")
        return True
    except Exception as error:
        print(f"An error occurred: {error}")
        return False

def read_message_template(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        message_template = file.read()
    return message_template

def send_emails_from_excel(service, excel_file, message_file, attachment_file=None):
    # Load both sheets: Email data from "Ids" and subject template from "Subject"
    xls = pd.ExcelFile(excel_file)
    email_data = pd.read_excel(xls, sheet_name='Ids')
    subject_data = pd.read_excel(xls, sheet_name='Subject')
    
    subject_template = subject_data['Subject'][0]

    email_data['Status'] = email_data['Status'].astype(str)
    message_template = read_message_template(message_file)

    for index, row in email_data.iterrows():
        name = row['Name']
        company = row['Company']
        to = row['Email Id']
        status = row.get('Status', '')

        if status == 'Mail sent':
            print(f"Skipping {to}, email already sent.")
            continue
        
        subject = subject_template.format(company=company)
        message_text = message_template.format(name=name)
        print(f"Preparing to send email to: {to} at {company}")
        
        message = create_message_with_attachment(to, subject, message_text, attachment_file)
        success = send_email(service, to, message)

        if success:
            email_data.at[index, 'Status'] = 'Mail sent'

    with pd.ExcelWriter(excel_file, engine='xlsxwriter') as writer:
        email_data.to_excel(writer, sheet_name='Ids', index=False)
        subject_data.to_excel(writer, sheet_name='Subject', index=False)

if __name__ == '__main__':
    service = gmail_authenticate()

    excel_file = r'C:\Users\skrishna\Desktop\Project_Gmail\Email_Ids.xlsx'
    message_file = r'C:\Users\skrishna\Desktop\Project_Gmail\Message.txt'
    attachment_file = r'C:\Users\skrishna\Desktop\Project_Gmail\Krishna_Dasyam_Resume.docx'

    send_emails_from_excel(service, excel_file, message_file, attachment_file)
