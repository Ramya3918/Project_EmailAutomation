import os
import pandas as pd
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly', 'https://www.googleapis.com/auth/gmail.send']

def gmail_authenticate():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    service = build('gmail', 'v1', credentials=creds)
    return service

def list_messages_matching_query(service, user_id, query=''):
    try:
        response = service.users().messages().list(userId=user_id, q=query).execute()
        messages = []
        if 'messages' in response:
            messages.extend(response['messages'])

        while 'nextPageToken' in response:
            page_token = response['nextPageToken']
            response = service.users().messages().list(userId=user_id, q=query, pageToken=page_token).execute()
            messages.extend(response['messages'])

        return messages
    except Exception as error:
        print(f'An error occurred: {error}')
        return []

def get_message(service, user_id, msg_id):
    try:
        message = service.users().messages().get(userId=user_id, id=msg_id, format='full').execute()
        return message
    except Exception as error:
        print(f'An error occurred: {error}')
        return None

def is_mailer_daemon(message):
    headers = message.get('payload', {}).get('headers', [])
    from_address = next((header['value'] for header in headers if header['name'] == 'From'), '').lower()
    
    if 'mailer-daemon@googlemail.com' in from_address:
        return True
    return False

def is_bounce_message(message):
    headers = message.get('payload', {}).get('headers', [])
    
    subject = next((header['value'] for header in headers if header['name'] == 'Subject'), '').lower()
    if any(keyword in subject for keyword in ['delivery status notification', 'undeliverable', 'returned mail', 'message could not be delivered']):
        return True
    
    body = message.get('snippet', '').lower()
    if any(keyword in body for keyword in [
        'address not found', 
        'the email account that you tried to reach does not exist', 
        'your message wasn\'t delivered', 
        'unable to receive mail',
        '550 5.1.1']):
        return True

    return False

def is_automated_reply(message):
    headers = message.get('payload', {}).get('headers', [])
    for header in headers:
        if header['name'] == 'Auto-Submitted' and header['value'].lower() in ['auto-replied', 'auto-generated']:
            return True
        if header['name'] == 'Precedence' and header['value'].lower() == 'bulk':
            return True
        if header['name'] == 'X-Auto-Response-Suppress':
            return True

    body = message.get('snippet', '').lower()
    if any(keyword in body for keyword in ['out of office', 'automated response', 'auto-reply', 'i am currently unavailable', 'thank you for your message']):
        return True

    return False

def is_pto_reply(message):
    body = message.get('snippet', '').lower()
    if any(keyword in body for keyword in [
        'pto', 
        'paid time off', 
        'on vacation', 
        'out of office', 
        'traveling', 
        'returning on', 
        'i will return on',
        'i am traveling']):
        return True
    return False

def is_human_reply(message):
    snippet = message.get('snippet', '').strip()
    if len(snippet) > 50:
        return True
    return False

def check_inbox_for_replies(service, email_data, subject_template):
    for index, row in email_data.iterrows():
        email_id = row['Email Id']
        status = row['Status']
        company = row['Company']

        if status != 'Mail sent':
            continue

        sent_subject = subject_template.format(company=company)
        print(f"Checking inbox for replies to: {email_id} - Subject: {sent_subject}")

        query = f'subject:"Re: {sent_subject}"'
        messages = list_messages_matching_query(service, 'me', query)

        if not messages:
            print(f"No reply found for {email_id}")
            continue

        for msg in messages:
            message = get_message(service, 'me', msg['id'])
            if message:
                if is_mailer_daemon(message):
                    print(f"Mail Delivery Failed (mailer-daemon) detected for {email_id}")
                    email_data.at[index, 'Status'] = 'Mail Delivery Failed'
                elif is_bounce_message(message):
                    print(f"Bounce (Delivery Failure - Address Not Found) detected for {email_id}")
                    email_data.at[index, 'Status'] = 'Delivery failed - Address not found'
                elif is_automated_reply(message):
                    print(f"Automated reply detected for {email_id}")
                    email_data.at[index, 'Status'] = 'Automated reply received'
                elif is_pto_reply(message):
                    print(f"PTO reply detected for {email_id}")
                    email_data.at[index, 'Status'] = 'PTO reply received'
                elif is_human_reply(message):
                    print(f"Human reply received for {email_id}")
                    email_data.at[index, 'Status'] = 'Human reply received'
                else:
                    print(f"Reply could not be classified for {email_id}")

    return email_data

def update_excel_file(excel_file, email_data, subject_data):
    with pd.ExcelWriter(excel_file, engine='xlsxwriter') as writer:
        email_data.to_excel(writer, sheet_name='Ids', index=False)
        subject_data.to_excel(writer, sheet_name='Subject', index=False)
    print(f"Excel file updated with reply status.")

if __name__ == '__main__':
    service = gmail_authenticate()

    excel_file = r'C:\Users\skrishna\Desktop\Project_Gmail\Email_Ids.xlsx'
    
    xls = pd.ExcelFile(excel_file)
    email_data = pd.read_excel(xls, sheet_name='Ids')
    subject_data = pd.read_excel(xls, sheet_name='Subject')

    subject_template = subject_data['Subject'][0]

    updated_email_data = check_inbox_for_replies(service, email_data, subject_template)

    update_excel_file(excel_file, updated_email_data, subject_data)
